import './App.css';
import List from './component/List';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <List/>
      </header>
    </div>
  );
}

export default App;
